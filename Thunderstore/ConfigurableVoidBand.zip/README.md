# ConfigurableVoidBand

A mod that allows configuration of some of Singularity Bands base and scaling settings.
All options can be found in-game through the settings menu, changes to settings are applied immediately.
Default configuration modifies Vand to scale with size and pull force